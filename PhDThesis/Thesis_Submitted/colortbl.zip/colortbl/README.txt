The colortbl package:

   Add colour to LaTeX tables. Requires array and color packages.
   Process colortbl.ins to produce the package file colortbl.sty.
   Process colortbl.dtx to get the documentation (this requires
   longtable hhline and dcolumn from the standard `tools'
   distribution.)
